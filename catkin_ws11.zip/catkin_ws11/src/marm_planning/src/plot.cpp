
#include <math.h>
#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/robot_trajectory/robot_trajectory.h>
 


ros::Publisher plan_positions_pub = nh.advertise<sensor_msgs::JointState>("/plan/fake_robot_state", 100);

void pubMotionData(trajectory_msgs::JointTrajectory planData) {

  sensor_msgs::JointState fake_robot_state;

  fake_robot_state.header = planData.header;

  ros::Time init_time(0.0);

  for (int i = 0; i < planData.points.size(); i++) {

    fake_robot_state.header.stamp = init_time + planData.points[i].time_from_start;

    fake_robot_state.position = planData.points[i].positions;

    fake_robot_state.velocity = planData.points[i].velocities;

    fake_robot_state.effort = planData.points[i].accelerations;

    plan_positions_pub.publish(fake_robot_state);

  }

}

